/**
 * interface for rendering the board
 */
public interface Renderer {
    void renderBoard(Board board);
}