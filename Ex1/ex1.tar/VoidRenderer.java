public class VoidRenderer implements Renderer {
    public void renderBoard(Board board) {
    }
}
