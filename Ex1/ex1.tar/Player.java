/**
 * Interface for a player in a game of Tic Tac Toe.
 */
public interface Player {
    void playTurn(Board board, Mark mark);
}